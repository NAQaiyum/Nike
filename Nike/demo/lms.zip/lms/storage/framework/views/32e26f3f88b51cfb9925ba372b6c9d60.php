<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Title -->
	<title>LMS</title>

	<!-- Meta -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="dexignlabs">
	<meta name="robots" content="index, follow">

	<meta name="keywords" content="admin, dashboard, Analytics Dashboard, Customizable Admin Panel, web app,School Management,Dashboard Template, academy, course, courses, e-learning, education, learning, learning management system, lms, school, student, teacher">   

	<meta name="description" content="LMS - Empower your educational institution with the all-in-one Education Admin Dashboard Template. Streamline administrative tasks, manage courses, track student performance, and gain valuable insights with ease. Elevate your education management experience with a modern, responsive, and feature-packed solution. Explore EduMin now for a smarter, more efficient approach to education administration.">

	<meta property="og:title" content="LMS">
	<meta property="og:description" content="LMS - Empower your educational institution with the all-in-one Education Admin Dashboard Template. Streamline administrative tasks, manage courses, track student performance, and gain valuable insights with ease. Elevate your education management experience with a modern, responsive, and feature-packed solution. Explore EduMin now for a smarter, more efficient approach to education administration.">
	
	<meta property="og:image" content="https://edumin.dexignlab.com/xhtml/social-image.png">

	<meta name="format-detection" content="telephone=no">

	<meta name="twitter:title" content="LMS">
	<meta name="twitter:description" content="LMS - Empower your educational institution with the all-in-one Education Admin Dashboard Template. Streamline administrative tasks, manage courses, track student performance, and gain valuable insights with ease. Elevate your education management experience with a modern, responsive, and feature-packed solution. Explore EduMin now for a smarter, more efficient approach to education administration.">

	<meta name="twitter:image" content="https://edumin.dexignlab.com/xhtml/social-image.png">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">

	<!-- STYLESHEETS -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/jqvmap/css/jqvmap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
    <link class="main-css" rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <?php echo $__env->make('layouts.include.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php echo $__env->make('layouts.include.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Chat box start
        ***********************************-->
		<?php echo $__env->make('layouts.include.chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--**********************************
            Chat box End
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <?php echo $__env->make('layouts.include.admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        
        <!--**********************************
            Sidebar end
        ***********************************-->
        <?php echo $__env->make('layouts.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
                <?php echo $__env->yieldContent('contents'); ?>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">LMS</a> 2024</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist//bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>"></script>

	<!-- Chart sparkline plugin files -->
    <script src="<?php echo e(asset('vendor/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins-init/sparkline-init.js')); ?>"></script>

	<!-- Chart Morris plugin files -->
    <script src="<?php echo e(asset('vendor/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/morris/morris.min.js')); ?>"></script>

    <!-- Init file -->
    <script src="<?php echo e(asset('js/plugins-init/widgets-script-init.js')); ?>"></script>

	<!-- Svganimation scripts -->
    <script src="<?php echo e(asset('vendor/svganimation/vivus.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/svganimation/svg.animation.js')); ?>"></script>

	<!-- Demo scripts -->
    <script src="<?php echo e(asset('js/dashboard/dashboard.js')); ?>"></script>
    
	<script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dlabnav-init.js')); ?>"></script>
</body>
</html><?php /**PATH /Applications/MAMP/htdocs/meshkat/faisal/lms/resources/views/layouts/master.blade.php ENDPATH**/ ?>