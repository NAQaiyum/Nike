<?php

use Illuminate\Support\Facades\Route;

$adminNamespace     = 'App\Http\Controllers\Admin';
$frontendNamespace  = 'App\Http\Controllers\Frontend';

Auth::routes();
Route::namespace($adminNamespace)->name('admin::')->prefix('admin')->middleware(['auth'])->group(function () {
    Route::get('', 'DashboardController@index');
    Route::get('admin/home', 'DashboardController@index')->name('dashboard');
});
